<div class="container">
        <div class="row">
          <div class="col-md-12 bg-light text-center COND">
            <hr class="my-1">
            <hr class="my-1">
            <p class="pp">Copyright &copy; Red Scouts</p>
            <hr class="my-1">
            <hr class="my-1">
          </div>
        </div>
    </div>